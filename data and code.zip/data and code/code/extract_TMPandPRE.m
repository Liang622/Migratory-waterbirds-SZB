clear
clc
close all
%% YR and MONTH
% set path
pre_path='G:\SURF_CLI_CHN_MUL_DAY_V3.0\SURF_CLI_CHN_MUL_DAY_V3.0_195101-201502\datasets\PRE\';
tmp_path='G:\SURF_CLI_CHN_MUL_DAY_V3.0\SURF_CLI_CHN_MUL_DAY_V3.0_195101-201502\datasets\TEM\';
%set year_month as yyyymm
a=xlsread([pre_path 'year_month.xlsx'],'10月到次年2月');
b=a(:,3);
c = num2str(b);
year_mon = cellstr(c);
clear a b c
%% precipitation from 1970-2020 and all stations
% set file name
name_P='SURF_CLI_CHN_MUL_DAY-PRE-13011-';
% read by year
for i=96:length(year_mon) %96 means started from 197001
filename_P(i-95,1)={[name_P year_mon{i} '.TXT']};
end
clear i name_P %

% read P
s=1;
for i=1:length(filename_P)
    i
    data=load([pre_path filename_P{i}]);
    n=length(data);  
    e=s+n-1;
    pre(s:e,:)=data;
    s=e+1;
end
clear data e i n s pre_path
%% TEMP from 1970-2020 and all stations
% set file name
name_T='SURF_CLI_CHN_MUL_DAY-TEM-12001-';
% read by year
for i=96:length(year_mon) %96 means started from 197001
filename_T(i-95,1)={[name_T year_mon{i} '.TXT']};
end
clear i name_T 

s=1;
for i=1:length(filename_T)
    i
    data=load([tmp_path filename_T{i}]);
    n=length(data);  
    e=s+n-1;
    tmp(s:e,:)=data;
    s=e+1;
end
clear data e i n s
%% TEMP in the south china
station=xlsread([tmp_path 'station_tmp.xlsx'],'南方站点');
% id of all stations 
station_all=tmp(:,1);

% find the south station id and only keep the south station
for i=1:length(station)
    i
    num=station(i,1);
    [row,~]=find(station_all==num);
    ind_tmp(i,1:2)={num row};
end
ind_tmp335=cell2mat(ind_tmp(:,2));
tmp335=tmp(ind_tmp335,:);
clear station_all i num row ind_tmp
%% precipitation(pre) in the south china
% id of all stations 
station_all=pre(:,1);

% find the south station id and only keep the south station
for i=1:length(station)
    i
    num=station(i,1);
    [row,~]=find(station_all==num);
    ind_pre(i,1:2)={num row};
end
ind_pre335=cell2mat(ind_pre(:,2));
pre335=pre(ind_tmp335,:);
clear station_all i num row ind_pre

%% test if the site and time info of tmp335 and pre335 are consistent
sum(ind_pre335-ind_tmp335)%test, if it is zero, means OK

station_date_tmp=tmp335(:,1:7);
station_date_pre=pre335(:,1:7);
sum(station_date_tmp-station_date_pre)%if it is all zero, means OK
%% merge tmp335 and pre335 as clm335，and look any un-monitored value

clm335=[tmp335(:,1:10) pre335(:,10)];
clm335(:,9)=[];%delete the nineth col with is the daily highest temp which not used in our research
clear ans ind_pre335 ind_tmp335 station pre tmp station_date_pre station_date_tmp

%average TEMP 32766: un-monitored value, assigin it by the mean value of the previous day and the latter day
avet=clm335(:,8); 
A=find(avet==32766); 
avet(A,1)=NaN; 
avet=fillmissing(avet,'linear') ;
clm335(:,8)=avet;
max(clm335(:,8)) %test the max
min(clm335(:,8)) %test the min

%low TEMP 32766: un-monitored value, assigin it by the mean value of the previous day and the latter day
lowt=clm335(:,9); 
B=find(lowt==32766);
lowt(B,1)=NaN; 
lowt=fillmissing(lowt,'linear') ;
clm335(:,9)=lowt;
max(clm335(:,9)) %test the max
min(clm335(:,9)) %test the min
clear A B avet lowt ans ind_avet ind_lowt tol i

%pre 32700: means very little preciptation，assign it as 0.01mm
prec=clm335(:,10);
prec(prec==999990)=0;
prec(prec==32766)=0;
prec(prec==32700)=0.1;% note, since the unite of precipitation is 0.1 mm, so 0.1 here means 0.01mm
prec(prec>32000 & prec<32999)=prec(prec>32000 & prec<32999)-32000;
prec(prec>31000 & prec<31999)=prec(prec>31000 & prec<31999)-31000;
prec(prec>30000 & prec<30999)=prec(prec>30000 & prec<30999)-30000;
clm335(:,10)=prec;
max(clm335(:,10)) %test the max
min(clm335(:,10)) %test the min
clear prec pre ans

%altitude larger than 100000: estimated data plus 100000 (0.1m), so minus 100000
dem=clm335(:,4);
dem(dem>100000)=dem(dem>100000)-100000;
clm335(:,4)=dem;
clear dem
%% Generate a cell array containing climate data based on start year, end year, and station ID. The climate data includes station basic information, average temperature, minimum temperature, and rainfall.
ind_oct=find(clm335(:,6)==10);
ind_nov=find(clm335(:,6)==11);
ind_dec=find(clm335(:,6)==12);
ind_win=union(union(ind_oct,ind_nov),ind_dec);
ind_jan=find(clm335(:,6)==1);
ind_feb=find(clm335(:,6)==2);
ind_mar=find(clm335(:,6)==3);%supposed to be NULL matrix
ind_spr=union(union(ind_jan,ind_feb),ind_mar);
clear ind_oct ind_nov ind_dec ind_jan ind_feb ind_mar
station=xlsread([tmp_path 'station_tmp.xlsx'],'南方站点');
for i=1:50
    i
    year_s=1969+i;
    year_e=year_s+1;
    for j=1:335
    station_num=station(j);
    ind_st=find(clm335(:,1)==station_num);

    ind_ys=find(clm335(:,5)==year_s);
    ind_ys_win=intersect(ind_ys,ind_win);

    ind_ye=find(clm335(:,5)==year_e);
    ind_ye_spr=intersect(ind_ye,ind_spr);

    ind_y=union(ind_ys_win,ind_ye_spr);

    ind_s_y=intersect(ind_st,ind_y);
    clm_cell=clm335(ind_s_y,:);
    row=335*(i-1)+j;
    clm_year_station(row,1:4)={year_s year_e station_num clm_cell};
    end
end
clear i year_s year_e ind_ys ind_ye ind_ye_spr ind_ye_win ind_s_y clm_cell row station_num
clear ind_spr ind_st ind_win ind_y ind_ys_win j station


%% calculate the freezing days, total rain, ave T, low T at each stataion every year
s=1
for i=1:length(clm_year_station)
    i
   year_s=clm_year_station{i,1};
   year_e=clm_year_station{i,2};
   station=clm_year_station{i,3};

   clm=clm_year_station{i,4};
   %sorted by time
   clm=sortrows(clm,7);
   clm=sortrows(clm,6);
   clm=sortrows(clm,5);
   %cal freeze
   T_ave=clm(:,8);
   P=clm(:,10);
   freeze_prc=freeze(T_ave,P); %id for freeze event(1), duration(2), started line(3), ended line(4)
   if size(freeze_prc,1)==0
       freeze_prc(1,5)=NaN;
       freeze_prc(1,6)=NaN;   
       freeze_prc(1,7)=NaN;
   else
   for j=1:size(freeze_prc,1)
       ind_clm=freeze_prc(j,3):freeze_prc(j,4);
       rainf=clm(ind_clm,10);
       avet=clm(ind_clm,8);
       lowt=clm(ind_clm,9);  
       freeze_prc(j,5)=sum(rainf);
       freeze_prc(j,6)=mean(avet);   
       freeze_prc(j,7)=min(lowt);            
   end 
   end

   lat=clm(1,2);
   long=clm(1,3);
   alt=clm(1,4);

   e=s+size(freeze_prc,1)-1 ;
   year_station=repmat([year_s year_e station lat long alt],size(freeze_prc,1),1); 
   freeze_info(s:e,:)=[year_station freeze_prc];

   
   s=e+1; 
   
   clear clm  T_ave P freeze_pr ind_clm  j year_station
end
clear a A ans avet b day_T down e  freeze_out freeze_prc i ind 
clear ind0 ind1 ind_3d ind_div ind_frz ind_P ind_T ind_TT ind_x lowt num num_max
clear num_min P_ave rainf s station up x y year_s year_e
%freeze_info There are 10 columns, from left to right: 1 Start year 2 End year 3 Site number 4 Latitude 5 Longitude 6 Altitude 7 Freeze number 8 Duration 9 Start row number 10 End row number 11 Total rainfall (0.1mm)
%% calculate freezing index for each year
ind_ocr=find(freeze_info(:,8)~=0);
freeze_info=freeze_info(ind_ocr,:);
clear ind_ocr

ind_high1=find(freeze_info(:,3)~=58718);
freeze_info=freeze_info(ind_high1,:);
ind_high2=find(freeze_info(:,3)~=57776);
freeze_info=freeze_info(ind_high2,:);
ind_high3=find(freeze_info(:,3)~=58626);
freeze_info=freeze_info(ind_high3,:);
clear ind_high1 ind_high3 ind_high2

dmin=min(freeze_info(:,8));
dmax=max(freeze_info(:,8));
rmin=min(freeze_info(:,11));
rmax=max(freeze_info(:,11));
avetmax=max(freeze_info(:,12));
avetmin=min(freeze_info(:,12));
lowtmax=max(freeze_info(:,13));
lowtmin=min(freeze_info(:,13));
clear ind_ocr

for j=1:length(freeze_info)
    d=freeze_info(j,8);
    r=freeze_info(j,11);
    avet=freeze_info(j,12);
    lowt=freeze_info(j,13);
    
    freeze_info(j,14)=(d-dmin)/(dmax-dmin);
    freeze_info(j,15)=(r-rmin)/(rmax-rmin);
    freeze_info(j,16)=(avet-avetmin)/(avetmax-avetmin);
    freeze_info(j,17)=(lowt-lowtmin)/(lowtmax-lowtmin);    
end

ind_na=find(~isnan(freeze_info(:,17)));
freeze_info=freeze_info(ind_na,:);
%
I1=mean(freeze_info(:,14));
I2=mean(freeze_info(:,15));
I3=mean(freeze_info(:,16));
I4=mean(freeze_info(:,17));

for j=1:length(freeze_info)
    freeze_info(j,18)=freeze_info(j,14)/I1+freeze_info(j,15)/I2-freeze_info(j,16)/I3-freeze_info(j,17)/I4;    
end

% At this point, the freeze index for each site is calculated. There are 15 columns, from left to right: 1 Start year 2 End year 3 Site number 4 Freeze number 5 Duration 6 Start row number 7 End row number 8 Total rainfall (0.1mm)
%9 Average temperature (0.1 ° C) 10 Minimum temperature (0.1 ° C) 11 Duration standardization 12 rainfall standardization 13 Average temperature standardization 14 Minimum temperature standardization 15freezing index
xlswrite('freeze_info.xlsx',freeze_info)

function freeze_out = freeze(T_ave,P)
% This function identifies freezing processes
% T_ave is the daily average temperature
% P is the daily precipitation
% freeze_out is a matrix where:
%   - The first column represents the freezing process ID
%   - The second column represents the number of freezing days
%   - The third column is the row number where the freezing process starts
%   - The fourth column is the row number where the freezing process ends
%% Days with a daily average temperature below 1°C for three consecutive days or more
ind_T=find(T_ave<10);% Rows where the temperature is below 1°C, unit is 0.1°C, so 10.
ind_P=find(P>0.01); % Rows where precipitation is greater than 0.01 (considering trace precipitation as rainfall)
ind1=intersect(ind_T,ind_P); % Days with both precipitation and a temperature below 1°C, identified as freezing days
% ind1=ind_T;
% Extract periods of three or more consecutive freezing days and store them in a cell array
if length(ind1)<3 % If the total number of freezing days is 0, 1, or 2, a freezing process cannot form
      freeze_out=[];
else
ind0=[ind1(3:length(ind1));0;0];
ind=ind0-ind1;% The difference: if the difference equals 2, it indicates that the current element and the next two elements form a consecutive sequence
num_min=find(ind==2);
num_max=num_min+2;
if length(num_min)==0 
    freeze_out=[];
else
for i=1:length(num_min)% length(num_min) indicates the number of freezing periods of three or more consecutive days
    num=num_min(i):num_max(i);
    ind_3d=ind1(num); % ind1 is the initial row index, extracting the row indices for the consecutive three days
    x(i,1:2)={num ind_3d};
end
% Merge sequences of three or more days into freezing periods
if size(x,1)==1
    ind_frz=[1 1];
else
% Determine whether the periods are consecutive
for i=1:(size(x,1)-1)
    up=max(x{i,2});
    down=max(x{i+1,2});
    y(i)=down-up;
end

ind_div=find(y~=1);
if max(ind_div)==size(x,1)
    ind_div=ind_div;
else
    ind_div(1,length(ind_div)+1)=size(x,1);
end

s=1;
for i=1:length(ind_div)
    ind_frz(i,1)=s;
    ind_frz(i,2)=ind_div(i);
    s=ind_div(i)+1;
end
end

for i=1:size(ind_frz,1)
%     i=2
    ind_x=ind_frz(i,1):ind_frz(i,2);
    ind_TT=cell2mat(x(ind_x,2));
    day_T=unique(ind_TT);
    
    freeze_out(i,1)=i;
    freeze_out(i,2)=length(day_T);
    freeze_out(i,3)=min(day_T);
    freeze_out(i,4)=max(day_T);
end

end
end
clear ans day_T down i ind ind0 ind1 ind_3d ind_div ind_frz ind_T ind_TT ind_x num num_max 
clear num_min s up x y ind_P
end

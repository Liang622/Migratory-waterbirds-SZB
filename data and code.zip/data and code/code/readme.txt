extract_TMPandPRE.m is the manuscript for extracting freezing information from weather stations
freeze.m are function will be used in the extract_TMPandPRE.m manuscripts for distinguuish freezing event




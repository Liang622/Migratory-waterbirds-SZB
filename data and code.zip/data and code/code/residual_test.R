######### residual test ############
#the residual is from the origin or R 
setwd("D:\\候鸟\\paper\\data and code\\data\\SFig8-11")

# load necessary packages
library(readxl)
library(ggplot2)

# Read data
rm(list = ls())

# standard sample
data<-rnorm(100, mean = 5, sd = 3)
hist(data, breaks = 10, xlab = "Residuals", col = "gray60")
qqnorm(data)
qqline(data, col = "red", lty = 2)
shapiro.test(data)

##################### 2poptrend_all
all <- read_xlsx("residual.xlsx",sheet='2poptrend_all')

jpeg(filename = "F_2poptrend_all.jpeg", width = 6, height = 6, units = "in", res = 600)
ggplot(all, aes(x = Residuals)) +
  geom_histogram(bins = 10, fill = "gray60", color = "white") +
  xlab("Residuals") +
  ylab("Frequency") +
  theme(
    axis.text = element_text(size = 13),                      # 修改坐标轴刻度标签的字体大小
    # y轴标题位置调整和角度
  )
dev.off() # 关闭设备以保存文件

jpeg(filename = "QQ_2poptrend_all.jpeg", width = 6, height = 6, units = "in", res = 600)
qqnorm(all$Residuals,main = "")
qqline(all$Residuals, col = "red", lty = 2)
dev.off() # 关闭设备以保存文件

shapiro.test(all$Residuals)



##################### 2poptrend_SZHK
SZHK <- read_xlsx("residual.xlsx",sheet='2poptrend_SZHK')

jpeg(filename = "F_2poptrend_SZHK.jpeg", width = 6, height = 6, units = "in", res = 600)
ggplot(SZHK, aes(x = Residuals)) +
  geom_histogram(bins = 10, fill = "gray60", color = "white") +
  xlab("Residuals") +
  ylab("Frequency") +
  theme(
    axis.text = element_text(size = 13),                      # 修改坐标轴刻度标签的字体大小
    # y轴标题位置调整和角度
  )
dev.off() # 关闭设备以保存文件

jpeg(filename = "QQ_2poptrend_SZHK.jpeg", width = 6, height = 6, units = "in", res = 600)
qqnorm(SZHK$Residuals,main = "")
qqline(SZHK$Residuals, col = "red", lty = 2)
dev.off() # 关闭设备以保存文件

shapiro.test(SZHK$Residuals)


##################### 2poptrend_all
Global <- read_xlsx("residual.xlsx",sheet='2poptrend_Global')

jpeg(filename = "F_2poptrend_Global.jpeg", width = 6, height = 6, units = "in", res = 600)
ggplot(Global, aes(x = Residuals)) +
  geom_histogram(bins = 10, fill = "gray60", color = "white") +
  xlab("Residuals") +
  ylab("Frequency") +
  theme(
    axis.text = element_text(size = 13),                      # 修改坐标轴刻度标签的字体大小
    # y轴标题位置调整和角度
  )
dev.off() # 关闭设备以保存文件

jpeg(filename = "QQ_2poptrend_Global.jpeg", width = 6, height = 6, units = "in", res = 600)
qqnorm(Global$Residuals,main = "")
qqline(Global$Residuals, col = "red", lty = 2)
dev.off() # 关闭设备以保存文件

shapiro.test(Global$Residuals)


##################### 4FP
FP <- read_xlsx("residual.xlsx",sheet='4FP')

jpeg(filename = "F_4FP.jpeg", width = 6, height = 6, units = "in", res = 600)
ggplot(FP, aes(x = Residuals)) +
  geom_histogram(bins = 10, fill = "gray60", color = "white") +
  xlab("Residuals") +
  ylab("Frequency") +
  theme(
    axis.text = element_text(size = 13),                      # 修改坐标轴刻度标签的字体大小
    # y轴标题位置调整和角度
  )
dev.off() # 关闭设备以保存文件

jpeg(filename = "QQ_4FP.jpeg", width = 6, height = 6, units = "in", res = 600)
qqnorm(FP$Residuals,main = "")
qqline(FP$Residuals, col = "red", lty = 2)
dev.off() # 关闭设备以保存文件

shapiro.test(FP$Residuals)


##################### 5HPD
HPD <- read_xlsx("residual.xlsx",sheet='5HPD')

jpeg(filename = "F_5HPD.jpeg", width = 6, height = 6, units = "in", res = 600)
ggplot(HPD, aes(x = Residuals)) +
  geom_histogram(bins = 10, fill = "gray60", color = "white") +
  xlab("Residuals") +
  ylab("Frequency") +
  theme(
    axis.text = element_text(size = 13),                      # 修改坐标轴刻度标签的字体大小
    # y轴标题位置调整和角度
  )
dev.off() # 关闭设备以保存文件

jpeg(filename = "QQ_5HPD.jpeg", width = 6, height = 6, units = "in", res = 600)
qqnorm(HPD$Residuals,main = "")
qqline(HPD$Residuals, col = "red", lty = 2)
dev.off() # 关闭设备以保存文件

shapiro.test(HPD$Residuals)


##################### 6NLI01
NLI01 <- read_xlsx("residual.xlsx",sheet='6NLI01')

jpeg(filename = "F_6NLI01.jpeg", width = 6, height = 6, units = "in", res = 600)
ggplot(NLI01, aes(x = Residuals)) +
  geom_histogram(bins = 10, fill = "gray60", color = "white") +
  xlab("Residuals") +
  ylab("Frequency") +
  theme(
    axis.text = element_text(size = 13),                      # 修改坐标轴刻度标签的字体大小
    # y轴标题位置调整和角度
  )
dev.off() # 关闭设备以保存文件

jpeg(filename = "QQ_6NLI01.jpeg", width = 6, height = 6, units = "in", res = 600)
qqnorm(NLI01$Residuals,main = "")
qqline(NLI01$Residuals, col = "red", lty = 2)
dev.off() # 关闭设备以保存文件

shapiro.test(NLI01$Residuals)



##################### 6NLI12
NLI12 <- read_xlsx("residual.xlsx",sheet='6NLI12')

jpeg(filename = "F_6NLI12.jpeg", width = 6, height = 6, units = "in", res = 600)
ggplot(NLI12, aes(x = Residuals)) +
  geom_histogram(bins = 10, fill = "gray60", color = "white") +
  xlab("Residuals") +
  ylab("Frequency") +
  theme(
    axis.text = element_text(size = 13),                      # 修改坐标轴刻度标签的字体大小
    # y轴标题位置调整和角度
  )
dev.off() # 关闭设备以保存文件

jpeg(filename = "QQ_6NLI12.jpeg", width = 6, height = 6, units = "in", res = 600)
qqnorm(NLI12$Residuals,main = "")
qqline(NLI12$Residuals, col = "red", lty = 2)
dev.off() # 关闭设备以保存文件

shapiro.test(NLI12$Residuals)




##################### 6NLI23
NLI23 <- read_xlsx("residual.xlsx",sheet='6NLI23')

jpeg(filename = "F_6NLI23.jpeg", width = 6, height = 6, units = "in", res = 600)
ggplot(NLI23, aes(x = Residuals)) +
  geom_histogram(bins = 10, fill = "gray60", color = "white") +
  xlab("Residuals") +
  ylab("Frequency") +
  theme(
    axis.text = element_text(size = 13),                      # 修改坐标轴刻度标签的字体大小
    # y轴标题位置调整和角度
  )
dev.off() # 关闭设备以保存文件

jpeg(filename = "QQ_6NLI23.jpeg", width = 6, height = 6, units = "in", res = 600)
qqnorm(NLI23$Residuals,main = "")
qqline(NLI23$Residuals, col = "red", lty = 2)
dev.off() # 关闭设备以保存文件

shapiro.test(NLI23$Residuals)










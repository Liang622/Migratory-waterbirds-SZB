####################################################################
################## abundance index of waterbirds ###################
####################################################################
# Check the current working directory
setwd("D:\\候鸟\\paper\\data and code\\data\\Fig2")

# load necessary packages
library(readxl)
library(poptrend)

# Read data
rm(list = ls())
all <- read_xlsx("Fig2 bird count data.xlsx",sheet='total')
mean(all$abundance)
var(all$abundance)
set.seed(11222)
trFit_all = ptrend(abundance ~ trend(YR, tempRE = TRUE, type = "smooth"),data = all)
# poptrend package's author suggest use tempRE = TRUE, and the auto-select fixed degree of freedom

# see the result
jpeg(filename = "pop_all.jpeg", width = 8, height = 6, units = "in", res = 600)
plot(trFit_all,xlab = "", ylab = "",secDeriv = FALSE,
     plotGrid=FALSE, tck = 0.03,cex.axis = 1.3, cex.lab = 1.3,
     lineCol = adjustcolor("black", alpha.f = 0.05),
     shadeCol = adjustcolor("#BEC1AC", alpha.f = 0.4),
     incCol = "#02a3ec",decCol = "#D55E00",
     xaxt = 'n', yaxt = 'n')
axis(side = 1, labels = TRUE, tck = 0.03)  # add x axis with label
axis(side = 2, labels = TRUE, tck = 0.03)  # add y axis with label
dev.off() 

summary(trFit_all)


# get the residuals, residual test see the residual_test.R
fitted_values_all <- trFit_all[["gam"]][["fitted.values"]]
residuals_all <- trFit_all[["gam"]][["residuals"]]



####################################################################
########### abundance index of local black-faced spoonbill #############
####################################################################
# Check the current working directory
setwd("D:\\候鸟\\paper\\data and code\\data\\Fig2")

# load necessary packages
library(readxl)
library(rtrim)

# Read data
#rm(list = ls())
SZHK <- read_xlsx("Fig2 bird count data.xlsx",sheet='black')
mean(SZHK$SZHK)
var(SZHK$SZHK)
set.seed(11222)
trFit_SZHK = ptrend(SZHK ~ trend(YR, tempRE = TRUE, type = "smooth"), data = SZHK)
# paper suggest use tempRE = TRUE, and the auto-select degree of freedom

# see the result
#figure will be plotted with global index latter
summary(trFit_SZHK)

# get the residuals, residual test see the residual_test.R
fitted_values_SZHK <- trFit_SZHK[["gam"]][["fitted.values"]]
residuals_SZHK <- trFit_SZHK[["gam"]][["residuals"]]



####################################################################
######### abundance index of global black-faced spoonbill ###########
####################################################################
# Check the current working directory
setwd("D:\\候鸟\\paper\\data and code\\data\\Fig2")

# load necessary packages
library(readxl)
library(rtrim)

# Read data
#rm(list = ls())
Global <- read_xlsx("Fig2 bird count data.xlsx",sheet='black')
mean(Global$Global)
var(Global$Global)
set.seed(11222)
trFit_Global = ptrend(Global ~ trend(YR, tempRE = TRUE, type = "smooth"), data = Global)

# see the result
#figure will be plotted latter
summary(trFit_Global)

# get the residuals, residual test see the residual_test.R
fitted_values_Global <- trFit_Global[["gam"]][["fitted.values"]]
residuals_Global <- trFit_Global[["gam"]][["residuals"]]



#########################plot ##################
jpeg(filename = "pop_Black.jpeg", width = 8, height = 6, units = "in", res = 600)
# Plot the first dataset (SZHK) with default y-axis on the left
plot(trFit_SZHK,axes = FALSE, xlab = "", ylab = "",secDeriv = FALSE,
     plotGrid=FALSE, tck = 0.00,cex.axis = 1.3, cex.lab = 1.3,ylim = c(1, 7),
     lineCol = adjustcolor("black", alpha.f = 0.05),ranef='point',
     shadeCol = adjustcolor("#b02d27", alpha.f = 0.3),
     incCol = "#02a3ec",decCol = "#D55E00",
     xaxt = 'n', yaxt = 'n')
axis(side = 2,tck = 0.02, at = c(1,3,5,7),labels = TRUE,)
axis(side = 1,tck = 0.02,labels = TRUE,) 

# Allow a new plot to be added to the existing plot
par(new = TRUE)

# Plot the second dataset (Global) without axes and labels
plot(trFit_Global,axes = FALSE, xlab = "", ylab = "",secDeriv = FALSE,
     plotGrid=FALSE, tck = 0.02,cex.axis = 1.3, cex.lab = 1.3,,ylim = c(1, 12),
     lineCol = adjustcolor("black", alpha.f = 0.05),ranef='point',
     shadeCol = adjustcolor("#0072B2", alpha.f = 0.2),
     incCol = "#02a3ec",
     decCol = "#D55E00",
     xaxt = 'n', yaxt = 'n')

# add right y axis
axis(side = 4,tck = 0.02, labels = TRUE, at = c(2, 4, 6,8, 10,12))  # add the 4th (right) axis


dev.off() # turn off to save figure

#################################



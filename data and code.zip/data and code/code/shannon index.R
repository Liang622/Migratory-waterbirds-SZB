

# Check the current working directory
setwd("D:\\候鸟\\paper\\data and code\\data\\Fig3\\Fig3b shannon")
rm(list = ls())


library(vegan)

# calculate one by one with comment or uncomment with DBA DBB MPNR non_reserve
otu=read.csv("DBA div.csv",row.names= 1) #
 # otu=read.csv("DBB div.csv",row.names= 1) #
# otu=read.csv("MPNR div.csv",row.names= 1) #
# otu=read.csv("non_reserve div.csv",row.names= 1) #
otu


Richness <- specnumber(otu) #Richness 
Shannon<- diversity(otu, index = 'shannon', base = 2) #Shannon_index
Pielou <- Shannon/ log(Richness, 2)  #Pielou 
GS <- diversity(otu, index = 'simpson')#Simpson
Invsimpson <- diversity(otu, index = 'invsimpson')# inv Simpson
AlphaResult <- data.frame(Richness, Shannon, Pielou, GS,  Invsimpson) #merge them in a dataframe


# export the result one by one with comment or uncomment with DBA DBB MPNR non_reserve
write.csv(AlphaResult, file="AlphaDiversity_DBA.csv")
# write.csv(AlphaResult, file="AlphaDiversity_DBB.csv")
# write.csv(AlphaResult, file="AlphaDiversity_MPNR.csv")
# write.csv(AlphaResult, file="AlphaDiversity_non_reserve.csv")


###NOTE!! since they tell the similar result, only shannon index was finally used in this paper 


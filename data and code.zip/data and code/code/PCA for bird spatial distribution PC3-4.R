#######################site distribution############################################
library("FactoMineR")
library("factoextra")  
library("ggplot2")
library("vegan")
library("corrplot")
library("stats")

iris=read.csv("D:\\����\\paper\\data and code\\data\\SFig3\\PCA data.csv",header = T,row.names= 1) #21 bird survey sites

#bird as variable
iris.pca <- PCA(iris[,-32], graph = FALSE,scale.unit = TRUE) 

eig.val <- get_eigenvalue(iris.pca)
eig.val                           


#show points' lable
a <- fviz_pca_ind(iris.pca,
                  geom.ind = c("point","text"),labelsize=4,
                  pointsize =3,
                  pointshape = 21,
                  fill.ind = iris$Species, # color by groups
                  palette="jco",
                  addEllipses = TRUE,ellipse.level=0.45,
                  legend.title = "Groups",
                  #axis
                  title=NULL)
# not show points label
a <- fviz_pca_ind(iris.pca,
                  axes = c(3, 4),
                  geom.ind = c("point"),labelsize=2,
                  pointsize =2,
                  pointshape = 21,
                  fill.ind = iris$Species, # color by groups
                  palette="jco",
                  addEllipses = TRUE,ellipse.level=0.45,
                  legend.title = "Groups",
                  #axis
                  title=NULL)


##modify font
windowsFonts(A=windowsFont("Arial"))
ggpubr::ggpar(a,title = "", xlim = c(-8.1,8.1), ylim = c(-5.0,5.0),xlab = "PC3 (12.25%)", ylab = "PC2 (11.36%)",
              font.x = c(16), font.y = c(16),lwd=1,col = "red",
              font.tickslab = c(16, "black"), font.family = "A",ggtheme = theme_minimal())
ggsave("x2.png", a ,width=5,height=3, dpi = 600)



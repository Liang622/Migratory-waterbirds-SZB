DBA div.csv, DBB div.csv, MPNR div.csv, non_reserve div was used for calulate shannon index by shannon index.R

shannon index.xlsx was the calculated result
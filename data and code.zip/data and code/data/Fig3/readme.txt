Fig3a PCA data.csv was used for PCA and plotted figures by "PCA for bird spatial distribution PC1-2.R"

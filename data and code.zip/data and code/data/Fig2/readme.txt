the data of Figure 2a-b and e-f can be found in this dataset.
Figure 2c-d was calculated and plotted by poptrend.R based on this dataset from sheet total and sheet black, respectively
